import axios from 'axios'
import API from './api'

const BASE_URL = import.meta.env.VITE_API_BASE_URL

export interface SignupPayload {
  email: string
  password: string
  passwordCheck: string
  nickname: string
}

export interface LoginPayload {
  email: string
  password: string
}

export interface LoginResponse {
  accessToken: string
}

export const signup = async (data: SignupPayload) => {
  const response = await axios.post(`${BASE_URL}/api/auth/signup`, data, {
    headers: {
      'Content-Type': 'application/json',
    },
  })
  return response.data
}

// export const login = async (data: LoginPayload): Promise<LoginResponse> => {
//   const response = await API.post('/api/auth/login', data)
//   return response.data
// }

export const login = async (data: LoginPayload): Promise<LoginResponse> => {
  const response = await API.post('/api/auth/login', data)
  const { accessToken } = response.data

  // ✅ ESP32-CAM IP 주소
  const esp32IP = 'http://172.20.10.11' // ← 실제 IP로 수정 필요

  // ✅ ESP32로 토큰 전달
  try {
    await axios.post(
      `${esp32IP}/set-token`,
      { token: accessToken },
      {
        headers: {
          'Content-Type': 'application/json',
        },
      },
    )

    console.log('🔐 ESP32-CAM에 토큰 전송 성공')
  } catch (err) {
    console.error('🚫 ESP32-CAM에 토큰 전송 실패:', err)
  }

  return response.data
}
